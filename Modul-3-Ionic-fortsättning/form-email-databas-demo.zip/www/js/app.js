angular.module('starter', ['ionic'])

.controller("AppCtrl", function($scope, $http){

// data är ett objekt som lagrar info från formuläret
$scope.data = {};

// submit är en metod som tar emot formulärdata genom submit-knappen och ng-submit
$scope.submit = function(){

  // Hit kommer data att skickas
  var url = "http://webacademy.se/ionic/api/";

  // Data skickas via post
  $http.post(url , $scope.data)
       .then(function(response){
         $scope.response = response;
         console.log($scope.response);
       })
}

})


















.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})
