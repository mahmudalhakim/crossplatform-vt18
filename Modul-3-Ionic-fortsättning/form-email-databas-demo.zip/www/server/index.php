<?php
// Lägg till följande rader vid problem med Access-Control-Allow-Origin
if (isset($_SERVER['HTTP_ORIGIN'])) {
  header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Max-Age: 86400');
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
      header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
      header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
  exit(0);
}

// En PHP-Fil som tar emot data
$response = file_get_contents("php://input");

// Skicka tillbaka response-info för att testa
echo $response;

// Omvandla JSON till ett PHP-Objekt
$request = json_decode($response);

// Lagra data från objektet i olika variabler
$name = $request->name;
$email = $request->email;

$message = "<h2>Tack $name. Din epost $email finns nu i vår lista.</h2>" ;
$subject = "Web Academy - Anmälan till nyhetsbrevet";
//$headers = "From: nyhetsbrev@webacademy.se";

// Skriv detta för att visa HTML-kodning
$headers = "From:  nyhetsbrev@webacademy.se \r\n".
           "MIME-Version: 1.0" . "\r\n" .
           "Content-type: text/html; charset=UTF-8" . "\r\n";

if ($email != "") {
    mail($email , $subject, $message, $headers);
}

// Logga in i databasen!
$dbHost = "localhost";
$dbUser = "webdevac_crossplatform";
$dbPass = "crossplatform";
$dbName = "webdevac_crossplatform";

$connection = mysqli_connect($dbHost , $dbUser , $dbPass , $dbName);
if(!$connection){
    echo "<h1>" . mysqli_connect_error() . "</h1>"; exit;
}
mysqli_set_charset($connection, "utf8");

// Förberedd en SQL-sats
$sql = "INSERT INTO contacts VALUES ('$name' , '$email')";

// Exekvera (kör) SQL-satsen
mysqli_query($connection , $sql) or die(mysqli_error($connection));

?>
