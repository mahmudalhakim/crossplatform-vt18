angular.module('starter', ['ionic'])

.config(function($stateProvider , $urlRouterProvider){

  $urlRouterProvider.otherwise("/tab/home");

  $stateProvider
  .state("tabs" , {
    url : "/tab",
    templateUrl : "templates/tabs.html",
    abstract:true
  }) // tabs

  .state("tabs.home" , {
    url: "/home",
    views : {
      "home-tab" : {
        templateUrl:"templates/home.html",
        controller: "HomeTabCtrl"
      }
    }
  }) // home
  
  .state("tabs.about" , {
    url: "/about",
    views : {
      "about-tab" : {
        templateUrl:"templates/about.html"
      }
    }
  }) // about



}) // Avslutar config

// Mina controllers
// OBS! Viktigt.
// Du måste skapa controllers som används i dina views
.controller("HomeTabCtrl" , function(){
    console.log("Detta är HomeTabCtrl");
})











.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})
