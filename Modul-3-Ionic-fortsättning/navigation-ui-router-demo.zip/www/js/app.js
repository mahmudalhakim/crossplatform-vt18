angular.module('starter', ['ionic'])

.config(function($stateProvider , $urlRouterProvider){

  $urlRouterProvider.otherwise("/tab/home");

  $stateProvider
  .state("tabs" , {
    url : "/tab",
    templateUrl : "templates/tabs.html",
    abstract:true
  }) // tabs

  .state("tabs.home" , {
    url: "/home",
    views : {
      "home-tab" : {
        templateUrl:"templates/home.html",
        controller: "HomeTabCtrl"
      }
    }
  }) // home

  .state("tabs.about" , {
    url: "/about",
    views : {
      "about-tab" : {
        templateUrl:"templates/about.html"
      }
    }
  }) // about

  // Skapa en sub-view
  .state("tabs.contact" , {
    url: "/contact",
    views : {
      "home-tab" : {
        templateUrl:"templates/contact.html"
      }
    }
  }) // contact

  .state("tabs.users" , {
    url: "/users",
    views : {
      "users-tab" : {
        templateUrl:"templates/users.html",
        controller: "UsersCtrl"
      }
    }
  }) // avsluta users

  .state("tabs.user" , {
    url: "/users/:ID",
    views : {
      "users-tab" : {
        templateUrl:"templates/user.html",
        controller: "UsersCtrl"
      }
    }
  }) // users



}) // Avslutar config

// Mina controllers
// OBS! Viktigt.
// Du måste skapa controllers som används i dina views
.controller("HomeTabCtrl" , function(){
    console.log("Detta är HomeTabCtrl");
})


.controller("UsersCtrl",function($scope , $stateParams){
  $scope.users = [
    {"ID": 1 , "Name" : "Mahmud"},
    {"ID": 2 , "Name" : "Kalle"},
    {"ID": 3 , "Name" : "Kajsa"}
  ]

  $scope.user  = $scope.users.find(function(item){
    console.log($stateParams);
    return item.ID == $stateParams.ID;
  })

})










.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})
